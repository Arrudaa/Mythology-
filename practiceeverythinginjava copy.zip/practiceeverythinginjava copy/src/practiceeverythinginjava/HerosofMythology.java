package practiceeverythinginjava;
import java.util.Scanner;
import java.util.Arrays;

public class HerosofMythology {

	public static void main(String[] args) {
		
		//made objects of each class 
		Mythology myth = new Mythology();
		GreekMythology gmyth = new GreekMythology();
		NorseMythology nmyth = new NorseMythology();
		
		//make scanner objects
		Scanner myObj = new Scanner(System.in);
		
		System.out.println("What is the origin of your mythology?");
			String place = myObj.nextLine();
			myth.setOrigin(place);
		
		System.out.println("What is the time of the origin?");
			int time = myObj.nextInt();
			myth.setOriginTimel(time);
			
		System.out.println("What is the name of your hero?");
			String hero = myObj.nextLine();
			myth.setHeroName(hero);
			myObj.nextLine();

			
		System.out.println("Please list number of heros");
			int size = myObj.nextInt();
			String myA[] = new String [size];
			
		System.out.println("Enter the hero one by one");
			myObj.nextLine();
			
			for(int i=0; i<size; i++) {
			myA[i] = myObj.nextLine();
		}
		myth.setHeros(myA);
		
		myth.orginMessage();
		myth.descriptionOfDeity();
		myth.heroDisplay();
		gmyth.OlympusEntry();
		nmyth.warWithVali();
		
		
}

}