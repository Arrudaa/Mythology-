package practiceeverythinginjava;

public class GreekMythology extends Mythology {
	
	String greekPoetryQuotes;
	
	public void OlympusEntry() {
		switch(getHeroName ()) {
		case "Zeus": System.out.println("You may enter Olympus! Go to the sky");
		break;
		case "Poseidon": System.out.println("You may enter Olympus! Go to the sea");
		break;
		case "Artemis": System.out.println("You may enter Olympus! Go to the forest");
		break;
		case "Aphrodite": System.out.println("You may enter Olympus! Go to thy Tinder");
		break;
		case "Athena": System.out.println("You may enter Olympus! Go to the library");
		break;
		default:
			System.out.println("Wrong mythology. Go away. ");
			break;
	}
	
	}
	public void poertyLine() {
		System.out.println(greekPoetryQuotes);
	}
	
}
