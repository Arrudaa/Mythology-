package practiceeverythinginjava;

public class NorseMythology extends Mythology {
	
	public String norsePoetryQuotes;
	
	public void poetryLine() {
		System.out.println(norsePoetryQuotes);
	}

	public void warWithVali() {
		switch(getHeroName()) {
		case "Thor": System.out.println("Welcome to your fight with Vali! Here's your hammer");
		break;
		case "Odin": System.out.println("Welcome to your fight with Vali! Here's your sword");
		break;
		case "Loki": System.out.println("Welcome to your fight with Vali! Here's your cloak");
		break;
		case "Baldr": System.out.println("Welcome to your fight with Vali! Here's your sunshine ");
		break;
		case "Freya": System.out.println("Welcome to your fight with Vali! Here's your bow and arrow");
		break;
		default:
			System.out.println("Wrong Mythology :(");
			break; 
	}
	}
	}