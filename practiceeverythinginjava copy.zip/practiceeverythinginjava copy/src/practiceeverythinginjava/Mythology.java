package practiceeverythinginjava;

public class Mythology {
	
	//private variables 
	private String origin;
	private int originTime;
	private String[]heros;
	private String heroName;
	
	//getters & setters
	public String getOrigin() {
		return origin;
	}
	public int getOriginTimel() {
		return originTime;
	}
	public String[] getHeros() {
		return heros;
	}
	public String getHeroName() {
		return heroName;
	}
	public void setOrigin(String origin) {
		this.origin = origin;
	}
	public void setOriginTimel(int originTime) {
		this.originTime = originTime;
	}
	public void setHeros(String[] heros) {
		this.heros = heros;
	}
	public void setHeroName(String heroName) {
		this.heroName = heroName;
	}
	public void power(String p) {
		System.out.println("My power is " + p);
	}
	public void orginMessage() {
		System.out.println("The orginal is: " + origin + "the time is: " + originTime);
	}
	public void heroDisplay () {
		
		for(int i = 0; i < heros.length; i++) {
			System.out.println("Your heros are: " + heros[i]);
		}
	}

	public void descriptionOfDeity() {
		switch(heroName) {
		case "Zeus": System.out.println("King of Olympus, sky and air services!");
		break;
		case "Poseidon": System.out.println("In charge of the sea services");
		break;
		case "Artemis": System.out.println("In charge of hunting services");
		break;
		case "Aphrodite": System.out.println("In charge of love services");
		break;
		case "Athena": System.out.println("In charge of knowledge services");
		break;
		case "Thor": System.out.println("Son of Odin, uses ligthing, has a hammer");
		break;
		case "Odin": System.out.println("Odin os the protector of the 9 realms, he is Thor's father");
		break;
		case "Loki": System.out.println("Cunning trickster and shape shifter");
		break;
		case "Baldr": System.out.println("Light, joy, purity and the summer sun ");
		break;
		case "Freya": System.out.println("Love, beauty, ferility and gold");
		break;
		default:
			System.out.println("Excuuusee mee! This is the North Pole! I am Santa");
			break; 
		}
	}
}
